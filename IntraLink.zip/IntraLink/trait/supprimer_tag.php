<?php
 // Récupérer les données
$ID = $_GET['IDD'];


// connexion a la base de donnee
require_once 'bd_cnx.php';

$req = "DELETE FROM TAG WHERE TAG_ID = $ID";
$bdd->exec($req);
// //apres la suppression retourner a la page pricipal
header("location:../tag.php");

?>