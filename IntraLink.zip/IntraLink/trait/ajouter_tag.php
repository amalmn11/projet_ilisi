<?php
  // Récupérer les données du formulaire
$nom=$_POST['nom'];


  // Se connecter à la base de données
require_once 'bd_cnx.php';


//*******1-preparer la requete
$req = "INSERT INTO TAG VALUES (NULL,?);";
$stmt=   $bdd->prepare($req);

//********2-binder les valeur a leur champs
$stmt->bindValue(1,$nom,PDO::PARAM_STR);



//*********3-executer la req
$stmt->execute();


header("location:../tag.php");

?>