<?php
  // Récupérer les données du formulaire
$nom=$_POST['nom'];
$descr=$_POST['descr'];
$budget=$_POST['budget'];
$statut=$_POST['statut'];

$date_d=$_POST['date_d'];
$date_f=$_POST['date_f'];

  // Se connecter à la base de données
require_once 'bd_cnx.php';


//*******1-preparer la requete
$req = "INSERT INTO PROJET VALUES (NULL,?,?,?,?,?,?);";
$stmt=   $bdd->prepare($req);

//********2-binder les valeur a leur champs
$stmt->bindValue(1,$nom,PDO::PARAM_STR);
$stmt->bindValue(2,$descr,PDO::PARAM_STR);
$stmt->bindValue(3,$budget,PDO::PARAM_STR);
$stmt->bindValue(4,$statut,PDO::PARAM_STR);
$stmt->bindValue(5,$date_d,PDO::PARAM_STR);
$stmt->bindValue(6,$date_f,PDO::PARAM_STR);


//*********3-executer la req
$stmt->execute();


header("location:../projet.php");

?>