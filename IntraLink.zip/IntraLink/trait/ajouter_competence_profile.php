<?php
//connexion à la base de donnees
require_once 'bd_cnx.php';

//-----> requete pour recuperer les noms des competences de la base de donnees
$req_competence="SELECT COMPETENCE_NOM from competence";
//executer la requete
$stmt_competence=$bdd->query($req_competence);
//parcourir le resultat
$competences=$stmt_competence->fetchAll(PDO::FETCH_ASSOC);
//--------> recuperation les titres des  niveaux
$req_niveau="SELECT NIVEAU_TITRE from niveau";
//executer la requete
$stmt_niveau=$bdd->query($req_niveau);
//parcourir le resultat
$niveaux=$stmt_niveau->fetchAll(PDO::FETCH_ASSOC);

//si bouton ajouter est cliqué on recupere les donnees
if(isset($_POST["ajouterCompetence"]))
{
$utilisateur_id=1;
$competence_nom=$_POST["competence_nom"];
$niveau=$_POST["niveau"];
//recherche des ids
//1
$req_id_comp="SELECT COMPETENCE_ID FROM competence where COMPETENCE_NOM=?";
$stmt_id_comp=$bdd->prepare($req_id_comp);
$stmt_id_comp->bindParam(1,$competence_nom,PDO::PARAM_STR);
$stmt_id_comp->execute();
$competence_id=$stmt_id_comp->fetch(PDO::FETCH_ASSOC);
//2
$req_id_niv="SELECT NIVEAU_ID FROM niveau where NIVEAU_TITRE=?";
$stmt_id_niv=$bdd->prepare($req_id_niv);
$stmt_id_niv->bindParam(1,$niveau,PDO::PARAM_STR);
$stmt_id_niv->execute();
$niveau_id=$stmt_id_niv->fetch(PDO::FETCH_ASSOC);
//la requete D'insertion
$req_ajout="INSERT INTO utilisateur_competence(UTILISATEUR_ID,COMPETENCE_ID,NIVEAU_ID)
VALUES(?,?,?)";
//preparer la requete
$stmt_ajout = $bdd->prepare($req_ajout);
// Liaison des valeurs aux paramètres de la requête
$stmt_ajout->bindParam(1, $utilisateur_id,PDO::PARAM_INT);
$stmt_ajout->bindParam(2, $competence_id["COMPETENCE_ID"],PDO::PARAM_INT);
$stmt_ajout->bindParam(3, $niveau_id["NIVEAU_ID"],PDO::PARAM_INT);
// Exécution de la requête
$stmt_ajout->execute();
//


}

?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modal Bootstrap</title>
    <!-- Dépendances Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ajouter Compétence</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Formulaire pour ajouter une compétence -->
                    <form method="post">
                        <div class="mb-3">
                           <label for="competence_nom" class="form-label">Nom de la Compétence:</label>
                           <select name="competence_nom" id="competence_nom" class="form-select">
                           <?php foreach($competences as $competence): ?>
                               <option value="<?php echo $competence["COMPETENCE_NOM"];  ?>"><?php echo $competence["COMPETENCE_NOM"];  ?></option>
                            <?php endforeach; ?>
                           </select>
                           
                        </div>
                        <div class="mb-3">
                           <label for="niveau" class="form-label">Niveau de la Compétence:</label>
                           <select name="niveau" id="competence_niveau" class="form-select">
                           <?php foreach($niveaux as $niveau): ?>
                               <option value="<?php echo $niveau["NIVEAU_TITRE"];  ?>"><?php echo $niveau["NIVEAU_TITRE"];  ?></option>
                            <?php endforeach; ?>
                           </select>
                           
                        </div>
                        <!-- Autres champs de formulaire ici -->
                        <button type="submit" name="ajouterCompetence" class="btn btn-primary">Ajouter</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
