
<?php

require_once 'bd_cnx.php';

///----------------------> Recuperation des comeptences
//l'id de l'utilisateur
$utilisateur_id = 1;

// Requête SQL
$sql = "SELECT c.COMPETENCE_NOM	, n.NIVEAU_TITRE
        FROM competence c
        JOIN utilisateur_competence uc ON uc.COMPETENCE_ID = c.COMPETENCE_ID
        JOIN niveau n ON uc.NIVEAU_ID = n.NIVEAU_ID
        WHERE uc.UTILISATEUR_ID = :utilisateur_id";

// Préparation de la requête
$stmt = $bdd->prepare($sql);

// Liaison du paramètre
$stmt->bindParam(':utilisateur_id', $utilisateur_id, PDO::PARAM_INT);

// Exécution de la requête
$stmt->execute();

// Récupération des résultats
$competences = $stmt->fetchAll(PDO::FETCH_ASSOC);


///--------------------> Recuperation des formations
// Requête SQL pour récupérer les formations de l'utilisateur
$sql_formation = "SELECT *
        FROM formation f
        JOIN utilisateur_formation uf ON uf.FORMATION_ID = f.FORMATION_ID
        WHERE uf.UTILISATEUR_ID = :utilisateur_id";

// Préparation de la requête
$stmt_formation = $bdd->prepare($sql_formation);

// Liaison du paramètre
$stmt_formation->bindParam(':utilisateur_id', $utilisateur_id, PDO::PARAM_INT);

// Exécution de la requête
$stmt_formation->execute();

// Récupération des résultats
$formations = $stmt_formation->fetchAll(PDO::FETCH_ASSOC);


///------------> Recuperation des Projets Réalisés
//la requete
$sql_projet="SELECT *
FROM projet p
JOIN utilisateur_projet up ON up.PROJET_ID = p.PROJET_ID
JOIN role_projet rp ON up.ROLE_PROJET_ID = rp.ROLE_PROJET_ID
WHERE up.UTILISATEUR_ID = :utilisateur_id;";
//executer la requete
// Préparation de la requête
$stmt_projet = $bdd->prepare($sql_projet);

// Liaison du paramètre
$stmt_projet->bindParam(':utilisateur_id', $utilisateur_id, PDO::PARAM_INT);

// Exécution de la requête
$stmt_projet->execute();

// Récupération des résultats
$projets = $stmt_projet->fetchAll(PDO::FETCH_ASSOC);

//--------> recuperation les titres des  niveaux
$req_niveau="SELECT NIVEAU_TITRE from niveau";
//executer la requete
$stmt_niveau=$bdd->query($req_niveau);
//parcourir le resultat
$niveaux=$stmt_niveau->fetchAll(PDO::FETCH_ASSOC);

//si bouton enregistrer est cliqué
if(isset($_POST["modifierCompetences"]))
{
 //recuperer les nouvelle donnees
// Boucle à travers les compétences pour récupérer les nouvelles données saisies/modifiées
foreach($competences as $competence) {
    $competenceNom = $competence['COMPETENCE_NOM']; //titre competence
    //niveau
    $nouveauNiveau =$_POST["niveau"];// niveau de competence
    $req_idd_niv="SELECT NIVEAU_ID from niveau where NIVEAU_TITRE='$nouveauNiveau'";
    $stmt_idd_niv=$bdd->query($req_idd_niv);
    $idd_niv=$stmt_idd_niv->fetch(PDO::FETCH_ASSOC);
    // Exécutez une requête SQL pour mettre à jour le niveau de compétence dans la base de données
    $sql = "UPDATE utilisateur_competence SET NIVEAU_ID=?  WHERE COMPETENCE_ID=? and UTILISATEUR_ID=?";
    $stmt = $bdd->prepare($sql);
    $stmt->bindParam(1,$idd_niv["NIVEAU_ID"], PDO::PARAM_INT);
    $stmt->bindParam(2, $competence["COMPETENCE_ID"], PDO::PARAM_INT);
    $stmt->bindParam(3, $utilisateur_id, PDO::PARAM_INT);
    $stmt->execute();
}
}
//requete de modification


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modal Bootstrap</title>
    <!-- Dépendances Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <!-- Modal -->
    <div  class="modal fade" id="modifierCompetence" tabindex="-1" aria-labelledby="modifierCompetence" aria-hidden="true">
        <div  class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Les competences:</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div   class="modal-body">
                    <!-- Formulaire pour ajouter une compétence -->
                    <form method="post">
                        <div class="mb-3">
                        <table width="95%">
                            <tr>
                                <td style="font-weight:bold;" width="60%">Titre de la competence</td>
                                <td style="font-weight:bold;" width="40%">Niveau de Maitrise</td>
                            </tr>
                            <?php  foreach($competences as $competence):?>
                                <tr>
                                    <td><?php echo $competence["COMPETENCE_NOM"]; ?></td>
                                    <td style="padding:7px;">
                                    <select  name="niveau" class="form-select">
                                    <?php foreach($niveaux as $niveau): ?>
                                        <option  <?php  if ($competence["NIVEAU_TITRE"] == $niveau["NIVEAU_TITRE"]) echo "selected"; ?>>
                                        <?php echo $niveau["NIVEAU_TITRE"];  ?></option>
                                    <?php endforeach; ?>
                                    </select>
                                    
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                        </div>
                        <!-- Autres champs de formulaire ici -->
                        <button type="submit" name="modifierCompetences" class="btn btn-primary">Enregistrer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
