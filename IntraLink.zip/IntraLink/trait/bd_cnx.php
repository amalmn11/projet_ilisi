<?php
      // Vérifier si la connexion a réussi
    try{
        
    $bdd = new PDO('mysql:host=localhost;dbname=projet_web2024','root','');
    // $bdd->query("SET NAMES 'UTF-8'");
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Connexion reussi";
    }
    catch(PDOException $e){
      //  echo "Connexion échouée :" .$e->getMessage();
    }    
?>