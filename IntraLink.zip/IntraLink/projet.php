<?php 
      include 'trait\liste_projet.php';
      include 'header.php' ;
?>



<!--start form-->
<div class="container-fluid pt-4 px-4">
<div class="bg-light rounded p-4">
    <h6 class="mb-4">Créer projet</h6>
    <form action="trait\ajouter_projet.php" method="post">
        <div class="row mb-3">
            <label  class="col-sm-2 col-form-label">Titre</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Entrer le titre" name="nom">
            </div>
        </div>
        <div class="row mb-3">
            <label  class="col-sm-2 col-form-label">Description</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Entrer le Budget" name="descr">
            </div>
        </div>
        <div class="row mb-3">
            <label  class="col-sm-2 col-form-label">Budget</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Entrer le Budget" name="budget">
            </div>
        </div>
        <div class="row mb-3">
            <label  class="col-sm-2 col-form-label">Statut</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Entrer le statut du projet" name="statut">
            </div>
        </div>
        <div class="row mb-3">
            <label  class="col-sm-2 col-form-label">Date début</label>
            <div class="col-sm-10">
                <input type="date" class="form-control"  name="date_d">
            </div>
        </div>
        <div class="row mb-3">
            <label  class="col-sm-2 col-form-label">Date fin</label>
            <div class="col-sm-10">
                <input type="date" class="form-control"  name="date_f">
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary">Ajouter</button>
    </form>
</div>
</div>

<!--end form-->


<!-- Recent Sales Start -->
<div class="container-fluid pt-4 px-4">
<div class="bg-light text-center rounded p-4">
    <div class="d-flex align-items-center justify-content-between mb-4">
        <h6 class="mb-0">Liste de projets</h6>
        <h6 class="mb-0"><?php echo 'Total : '.$nb_comptes;?></h6>
    </div>
    <div class="table-responsive">
        <table class="table text-start align-middle table-bordered table-hover mb-0">
            <thead>
                <tr class="text-dark">
                    <th scope="col">Titre</th>
                    <th scope="col">Deescription</th>
                    <th scope="col">Budget</th>
                    <th scope="col">Statut</th>
                    <th scope="col">Date Début</th>
                    <th scope="col">Date Fin</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($lignes as  $ligne):  ?>
                <tr>
                   
                <td><?php echo $ligne['PROJET_TITRE']?></td>
                <td><?php echo $ligne['PROJET_DESCR']?></td>
                <td><?php echo $ligne['BUDGET']?></td>
                <td><?php echo $ligne['STATUT']?></td>
                <td><?php echo $ligne['PROJET_DATE_DEBUT']?></td>
                <td><?php echo $ligne['PROJET_DATE_FIN']?></td>
                <td><a class="btn btn-sm btn-danger" href="trait\supprimer_projet.php?IDD=<?php echo $ligne['PROJET_ID']; ?>">Supprimer</a></td>
                </tr>
                
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
<!-- Recent Sales End -->

<!-- Footer Start -->
<div class="container-fluid pt-4 px-4">
<div class="bg-light rounded-top p-4">
    <div class="row">
        <div class="col-12 col-sm-6 text-center text-sm-start">
            &copy; <a href="#">ProjetWEB2024</a>, All Right Reserved. 
        </div>
    
    </div>
</div>
</div>
<!-- Footer End -->

</div>
<!--end content-->

<?php include 'footer.php' ?>