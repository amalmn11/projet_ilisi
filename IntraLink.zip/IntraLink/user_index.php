<?php

include "trait\bd_cnx.php";
require_once 'trait\auth.inc.php';




///----------------------> Recuperation des comeptences
//l'id de l'utilisateur
$utilisateur_id =  $_SESSION["user_id"];


// Requête SQL
$sql = "SELECT c.COMPETENCE_NOM	, n.NIVEAU_TITRE
        FROM competence c
        JOIN utilisateur_competence uc ON uc.COMPETENCE_ID = c.COMPETENCE_ID
        JOIN niveau n ON uc.NIVEAU_ID = n.NIVEAU_ID
        WHERE uc.UTILISATEUR_ID = :utilisateur_id";



// Préparation de la requête
$stmt = $bdd->prepare($sql);

// Liaison du paramètre
$stmt->bindParam(':utilisateur_id', $utilisateur_id, PDO::PARAM_INT);

// Exécution de la requête
$stmt->execute();

// Récupération des résultats
$competences = $stmt->fetchAll(PDO::FETCH_ASSOC);




///--------------------> Recuperation des formations
// Requête SQL pour récupérer les formations de l'utilisateur
$sql_formation = "SELECT *
        FROM formation f
        JOIN utilisateur_formation uf ON uf.FORMATION_ID = f.FORMATION_ID
        WHERE uf.UTILISATEUR_ID = :utilisateur_id";

// Préparation de la requête
$stmt_formation = $bdd->prepare($sql_formation);

// Liaison du paramètre
$stmt_formation->bindParam(':utilisateur_id', $utilisateur_id, PDO::PARAM_INT);

// Exécution de la requête
$stmt_formation->execute();

// Récupération des résultats
$formations = $stmt_formation->fetchAll(PDO::FETCH_ASSOC);


///------------> Recuperation des Projets Réalisés
//la requete
$sql_projet="SELECT *
FROM projet p
JOIN utilisateur_projet up ON up.PROJET_ID = p.PROJET_ID
JOIN role_projet rp ON up.ROLE_PROJET_ID = rp.ROLE_PROJET_ID
WHERE up.UTILISATEUR_ID = :utilisateur_id;";
//executer la requete
// Préparation de la requête
$stmt_projet = $bdd->prepare($sql_projet);

// Liaison du paramètre
$stmt_projet->bindParam(':utilisateur_id', $utilisateur_id, PDO::PARAM_INT);

// Exécution de la requête
$stmt_projet->execute();

// Récupération des résultats
$projets = $stmt_projet->fetchAll(PDO::FETCH_ASSOC);
?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Professionals Resume HTML Bootstrap Template | Smarteyeapps.com</title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
    <!-- Option 1: Include in HTML -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <style>
    .btn-icon {
      background: none;
      border: none;
      padding: 0;
      cursor: pointer;
      font-size: inherit;
    }
    .btn-icon:hover .bi {
        color:gray;
    }
  </style>
  <!-------------------->
 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>

     
</head>

<body>

<!---------------->
    <!-- Navbar Start -->
    <div class="navbar navbar-expand-lg navbar-light bg-grey" style="border-bottom: 1px solid #e0e0e0;">
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <div class="navbar-nav align-items-center ms-auto">
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/profile.jpg" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo $_SESSION['utilisateur']?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <a href="#" class="dropdown-item">Mon Profile</a>
                    <a href="trait\decnx.php" class="dropdown-item">Se déconnecter</a>
                </div>
            </div>
        </div>
    </nav>
</div>
    <!-- Navbar End -->
<!----------------->    
    <div class="container-fluid overcover">
        <div class="container profile-box">
            <div class="top-cover">
                <div class="covwe-inn">
                    <div class="row no-margin">
                        <div class="col-md-3 img-c">
                            <img src="assets/images/profile.jpg" alt="">
                        </div>
                        <div class="col-md-9 tit-det">
                            <h2 style="margin-bottom: 130px;"><?php echo $_SESSION['utilisateur']?> / Developpeuse web</h2>
                        </div>
                    </div>
                </div>
            </div>
            <ul class="nav nav-tabs" id="myTab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Profile</a>
              </li>
            </ul>
            <div class="tab-content" id="myTabContent">
               <!-------- Home -->
               <div style="background-color:#f2f2f2;" class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <div   class="row no-margin home-det">
                     <!-------- Carte 1----->
                    <div style="background-color:white; width:95%;margin-left:20px;margin-top:10px;margin-bottom:10px;" class="col-md-8 home-dat">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
    <!-- Title -->
    <h2 class="rit-titl" style="margin-right: auto;"><i class="bi bi-person-check-fill"></i> Competences</h2>
                        <!-- Button -->
                        <button type="button" class="btn-icon" data-bs-toggle="modal" data-bs-target="#modifierCompetence">
                            <i class="bi bi-pen"></i>
                        </button>
                        <?php include "trait\modifier_competence.php"; ?>
                    </div>
                      <div class="profess-cover row no-margin">
                      
                      <div class="col-md-6">
                                <?php
                                // Votre code PHP pour récupérer les informations de compétence et de niveau de l'utilisateur
                                // Supposons que vous avez les informations dans un tableau $competences avec chaque élément contenant le titre de la compétence et son niveau
                                foreach ($competences as $competence) {
                                    $niveau = $competence["NIVEAU_TITRE"]; // Supposons que vous avez récupéré le niveau de compétence pour chaque compétence
                                    $progress_width = 0; // Initialiser la largeur de la barre de progression
 
                                    // Calculer la largeur de la barre de progression en fonction du niveau de compétence
                                    if ($niveau == "Débutant") {
                                        $progress_width = 20;
                                    } elseif ($niveau == "Intermédiaire") {
                                        $progress_width = 40;
                                    } elseif ($niveau == "Avancé") {
                                        $progress_width = 60;
                                    } elseif ($niveau == "Expert") {
                                        $progress_width = 80;
                                    } elseif ($niveau == "Maîtrise complète") {
                                        $progress_width = 100;
                                    }
                                ?>
                                <div class="prog-row row">
                                    <div class="col-sm-6">
                                        <?php echo $competence["COMPETENCE_NOM"]; ?> <!-- Titre de la compétence -->
                                    </div>
                                    <div class="col-sm-6">
                                        <div style="margin-top:7px;width:500px;height:15px;" class="progress">
                                            <div class="progress-bar" role="progressbar" style="width: <?php echo $progress_width; ?>%" aria-valuenow="<?php echo $progress_width; ?>" aria-valuemin="0" aria-valuemax="100"><p style="margin-top:14px;"><?php echo $competence["NIVEAU_TITRE"]; ?></p></div>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php
                                }
                                ?>
                    </div>
                    </div>
                    <ul class="btn-link">
                   
                   
     
            <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="bi bi-plus"></i> Ajouter Compétence</a>
    
    
             <?php include 'trait\ajouter_competence_profile.php'; ?>
                    </div>
                     <!-------- Carte 2----->
                     <div style="background-color:white; width:95%;margin-left:20px;margin-top:10px;margin-bottom:10px;" class="col-md-8 home-dat">
                        <h2 class="rit-titl"><i class="bi bi-headset"></i> Formation</h2>
                      <?php foreach($formations as $formation): ?>
                      <div class="profess-cover row no-margin">
                            <div class="row exp-row">
                                <h6 style="font-weight: bold; font-size:18px"><?php echo $formation["THEME"]; ?></h6>
                                <p><?php echo $formation["FORMATION_DESCR"]; ?></p><br>
                                <span style="font-size:16px">Formateur:</span><i style="margin-right:25px; font-size:14px"><?php echo $formation['FORMATEUR']; ?></i>
                                <span style="font-size:16px">Date:</span><i style="font-size:14px"><?php echo $formation["FORMATION_DATE_DEBUT"]; ?></i>
                                
                            </div>
                      </div>
                      <?php endforeach; ?>
                    
                    </div>
                      </ul>
                     <!-------- Carte 3----->
                     <div style="background-color:white; width:95%;margin-left:20px;margin-top:10px;margin-bottom:10px;" class="col-md-8 home-dat">
                        <h2 class="rit-titl"><i class="bi bi-laptop"></i> Projets</h2>
                      <div class="profess-cover row no-margin">
                      <?php if (empty($projets)): ?>
                        <div class="row exp-row"><p style="color: grey;">Aucun projet trouvé pour le moment. <smal>Les projets auxquels vous participez seront affichés ici.</smal></p></div>
                            <?php else: ?>
                            <?php foreach($projets as $projet): ?>
                            <div class="row exp-row">
                                <h6 style="font-weight: bold;"><?php echo $projet["PROJET_TITRE"]; ?></h6>
                                <span>Role dans Projet:</span><i style="margin-right:25px;"><?php echo $projet["ROLE_PROJET_TITRE"]; ?></i>
                                <span>Date Debut:</span><i style="margin-right:25px;"><?php echo $projet["PROJET_DATE_DEBUT"]; ?></i>
                                <span>Date Fin:</span><i style="margin-right:25px;"><?php echo $projet["PROJET_DATE_FIN"]; ?></i>
                                <p><span>Description:</span><?php echo $projet["PROJET_DESCR"]; ?></p><br>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>
                      </div>
                     
                    </div>
                    
                </div>
                
            </div>            
              <!-------- HOME----->
              
              <!-------- Profile -->
              <div class="tab-pane fade exp-cover" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <div class="data-box">
                    <div class="row no-margin">
                        <object type="text/html" data="modifier_profile.php" width="100%" height="900px"></object>
                    </div>   
                </div>
            </div>
              <!-------- Profile -->
              <!-------- Resume -->
              
              <!-------- FIN Resume -->
              <!-------- Contact -->
              <!--------  FIN Contact -->
            </div>
        </div>
    </div>
</body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/script.js"></script>

<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script> 
<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.1/dist/js/bootstrap.bundle.min.js"></script> 
<script type="text/javascript"></script>

<script>
  // Fonction pour récupérer la liste des pays depuis l'API REST Countries
  function fetchCountries() {
      fetch('https://restcountries.com/v3.1/all')
          .then(response => response.json())
          .then(data => {
              const countrySelect = document.getElementById('countrySelect');
              data.forEach(country => {
                  const option = document.createElement('option');
                  option.value = country.name.common;
                  option.textContent = country.name.common;
                  countrySelect.appendChild(option);
              });
          })
          .catch(error => {
              console.error('Une erreur s\'est produite lors de la récupération des pays : ', error);
          });
  }

  // Appel de la fonction pour récupérer les pays lors du chargement de la page
  window.onload = fetchCountries;
</script>

</html>
