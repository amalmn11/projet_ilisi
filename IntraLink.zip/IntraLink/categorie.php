<?php 
      include 'trait\liste_categorie.php';
      include 'header.php' ;
?>



<!--start form-->
<div class="container-fluid pt-4 px-4">
<div class="bg-light rounded p-4">
    <h6 class="mb-4">Ajouter nouvelle catégorie</h6>
    <form action="trait\ajouter_categorie.php" method="post">
        <div class="row mb-3">
            <label  class="col-sm-2 col-form-label">Nom  </label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Entrer la catégorie" name="nom">
            </div>
        </div>
    
        <button type="submit" class="btn btn-primary">Ajouter</button>
    </form>
</div>
</div>

<!--end form-->


<!-- Recent Sales Start -->
<div class="container-fluid pt-4 px-4">
<div class="bg-light text-center rounded p-4">
    <div class="d-flex align-items-center justify-content-between mb-4">
        <h6 class="mb-0">Liste de catégories</h6>
        <h6 class="mb-0"><?php echo 'Total : '.$nb_comptes;?></h6>
    </div>
    <div class="table-responsive">
        <table class="table text-start align-middle table-bordered table-hover mb-0">
            <thead>
                <tr class="text-dark">
                    <th scope="col">Categorie</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($lignes as  $ligne):  ?>
                <tr>
                   
                <td><?php echo $ligne['CATEGORIE_LIBELLE']?></td>
                <td><a class="btn btn-sm btn-danger" href="trait\supprimer_categorie.php?IDD=<?php echo $ligne['CATEGORIE_ID']; ?>">Supprimer</a></td>
                </tr>
                
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
<!-- Recent Sales End -->

<!-- Footer Start -->
<div class="container-fluid pt-4 px-4">
<div class="bg-light rounded-top p-4">
    <div class="row">
        <div class="col-12 col-sm-6 text-center text-sm-start">
            &copy; <a href="#">ProjetWEB2024</a>, All Right Reserved. 
        </div>
    
    </div>
</div>
</div>
<!-- Footer End -->

</div>
<!--end content-->

<?php include 'footer.php' ?>