<?php

require_once '..\..\controllers\auth\auth_inc.php';
include '..\headerX\header_user.php';

?>

    welcome user
    <button><a href="../../controllers/db/deconnexion.php">decnx</a></button>


<?php
// require_once '..\..\controllers\auth\auth_inc.php';
include '..\headerX\footer.php';

?>